package com.example.streamzone.model

data class MovieSearchResponse(
    val Search: List<Movie>,
    val totalResults: String,
    val Response: String
)

data class MovieDetailsResponse(
    val Title: String,
    val Year: String,
    val Genre: String,
    val Plot: String,
    val Poster: String
)

