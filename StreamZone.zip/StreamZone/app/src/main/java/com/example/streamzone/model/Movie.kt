package com.example.streamzone.model

data class Movie(
    val imdbID: String,
    val Title: String,
    val Year: String,
    val Poster: String
)