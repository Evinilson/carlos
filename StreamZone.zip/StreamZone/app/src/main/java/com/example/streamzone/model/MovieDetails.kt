package com.example.streamzone.model

data class MovieDetails(
    val title: String,
    val year: String,
    val genre: String,
    val synopsis: String
)