package com.example.streamzone.network

import com.example.streamzone.model.MovieDetailsResponse
import com.example.streamzone.model.MovieSearchResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface OMDbApiService {
    @GET("/")
    suspend fun searchMovies(
        @Query("s") search: String,
        @Query("apikey") apiKey: String
    ): MovieSearchResponse

    @GET("/")
    suspend fun getMovieDetails(
        @Query("i") imdbId: String,
        @Query("apikey") apiKey: String
    ): MovieDetailsResponse
}
