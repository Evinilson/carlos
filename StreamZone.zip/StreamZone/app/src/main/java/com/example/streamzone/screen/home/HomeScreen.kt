package com.example.streamzone.screen.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.streamzone.model.Movie
import com.example.streamzone.network.OMDbApiService
import com.example.streamzone.network.RetrofitClient
import com.example.streamzone.components.MovieCard
import kotlinx.coroutines.launch
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavHostController) {
    val apiKey = "23b7a071" // Substitua pela sua chave da OMDb API
    val omdbApi = RetrofitClient.instance.create(OMDbApiService::class.java)

    var searchQuery by remember { mutableStateOf(TextFieldValue("")) }
    var movies by remember { mutableStateOf<List<Movie>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    // Busca inicial com filmes aleatórios
    LaunchedEffect(Unit) {
        val keywords = listOf("Matrix", "Harry Potter", "Avengers", "Batman", "Inception", "Frozen")
        val randomKeyword = keywords[Random.nextInt(keywords.size)]

        fetchMovies(randomKeyword, omdbApi, apiKey) { result ->
            result.onSuccess {
                movies = it.take(20) // Limitar a 20 filmes
                isLoading = false
            }.onFailure { error ->
                errorMessage = error.message ?: "Erro desconhecido"
                isLoading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    TextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Pesquisar filmes...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.textFieldColors(
                            containerColor = Color.Transparent,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                },
                actions = {
                    IconButton(onClick = {
                        if (searchQuery.text.isNotEmpty()) {
                            coroutineScope.launch {
                                isLoading = true
                                fetchMovies(searchQuery.text, omdbApi, apiKey) { result ->
                                    result.onSuccess {
                                        movies = it.take(20) // Limitar a 20 filmes
                                        isLoading = false
                                    }.onFailure { error ->
                                        errorMessage = error.message ?: "Erro desconhecido"
                                        isLoading = false
                                    }
                                }
                            }
                        }
                    }) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Buscar")
                    }
                },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        },
        content = { padding ->
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (errorMessage.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = errorMessage, style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.padding(padding),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(movies) { movie ->
                        MovieCard(movie = movie, onClick = {
                            navController.navigate("details/${movie.imdbID}")
                        })
                    }
                }
            }
        }
    )
}

private suspend fun fetchMovies(
    searchQuery: String,
    api: OMDbApiService,
    apiKey: String,
    onResult: (Result<List<Movie>>) -> Unit
) {
    try {
        val response = api.searchMovies(searchQuery, apiKey)
        if (response.Response == "True") {
            onResult(Result.success(response.Search))
        } else {
            onResult(Result.failure(Exception("Nenhum filme encontrado.")))
        }
    } catch (e: Exception) {
        onResult(Result.failure(e))
    }
}
